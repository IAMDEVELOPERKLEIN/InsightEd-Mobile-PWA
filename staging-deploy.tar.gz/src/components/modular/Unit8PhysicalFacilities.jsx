import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { FiX, FiCheckCircle, FiEdit2, FiCheck, FiArrowRight, FiArrowLeft, FiChevronLeft, FiPlus, FiTrash2, FiMapPin, FiSave, FiSearch, FiChevronDown, FiUnlock, FiAlertTriangle, FiClock, FiAlertOctagon, FiCloudLightning, FiTrendingUp } from "react-icons/fi";
import { motion, AnimatePresence } from "framer-motion";
import SuccessModal from "../SuccessModal";
import { saveUnitDraft, getUnitDraft, clearUnitDraft } from "../../db";
import { MapContainer, TileLayer, Marker, Popup, Rectangle, useMapEvents, useMap } from "react-leaflet";
import "leaflet/dist/leaflet.css";
import L from "leaflet";
// Fix for default marker icon in react-leaflet using unpkg to bypass rollup bundle errors
const DefaultIcon = L.icon({
    iconUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon.png',
    iconRetinaUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon-2x.png',
    shadowUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-shadow.png',
    iconSize: [25, 41],
    iconAnchor: [12, 41],
    popupAnchor: [1, -34],
    tooltipAnchor: [16, -28],
    shadowSize: [41, 41]
});

L.Marker.prototype.options.icon = DefaultIcon;

// Helper: fly/zoom to school coordinates when they load
const RecenterMap = ({ center }) => {
    const map = useMap();
    useEffect(() => {
        if (center && center[0] && center[1]) {
            map.flyTo(center, 19, { duration: 1.5 });
        }
    }, [center, map]);
    return null;
};

// ── Constants ──────────────────────────────────────────────────────────
const DEFAULT_BUILDING_TYPES = [
    "Academic Building",
    "Laboratory Building",
    "Administrative Building",
    "Multi-Purpose Building",
    "Covered Court",
    "Canteen/Feeding Center",
    "Clinic",
    "Library",
    "Comfort Room (CR) Building",
    "Storage Building",
    "Teacher's Cottage",
    "Security/Guard House",
    "Gymnasium"
];

export default function Unit8PhysicalFacilities() {
    const navigate = useNavigate();

    // ── Global State ─────────────────────────────────────────────────────────
    const [schoolId, setSchoolId] = useState("");
    const [loading, setLoading] = useState(false);
    const [showSuccess, setShowSuccess] = useState(false);
    const [showWelcomeBack, setShowWelcomeBack] = useState(false);
    const [showDraftModal, setShowDraftModal] = useState(false);
    const [schoolData, setSchoolData] = useState(null);
    const [currentPage, setCurrentPage] = useState(1); // 1-5 Wizard Stages
    const [buildingTypes, setBuildingTypes] = useState(() => {
        const cached = localStorage.getItem("nsbi_building_types");
        return cached ? JSON.parse(cached) : DEFAULT_BUILDING_TYPES;
    });
    const [isBuildingDropdownOpen, setIsBuildingDropdownOpen] = useState(false);
    const [buildingSearch, setBuildingSearch] = useState("");

    // Teacher selection for advisory
    const [teachers, setTeachers] = useState([]);

    // Map & Space State
    const [spaces, setSpaces] = useState([]);
    const [centerMap, setCenterMap] = useState([14.5995, 120.9842]); // Default Manila
    const [isFormVisible, setIsFormVisible] = useState(false);

    // New space form
    const [newSpace, setNewSpace] = useState({
        space_name: "New Building Area",
        center_lat: null,
        center_lng: null,
        length_m: 10,
        width_m: 10
    });

    const totalAreaSqm = (newSpace.length_m || 0) * (newSpace.width_m || 0);

    // ── Phase 2: Building Inventory State ────────────────────────────────────
    const [buildings, setBuildings] = useState([]);
    const [showBuildingModal, setShowBuildingModal] = useState(false);

    const currentYear = new Date().getFullYear();
    const [buildingFormData, setBuildingFormData] = useState({
        building_name: "",
        category: "Academic Building",
        storey: 1,
        classroom: 1,
        year_completed: currentYear,
        remarks: "",
        status: "Good Condition",
        condemn_age: false,
        condemn_hazard: false,
        condemn_calamity: false,
        condemn_upgrade: false
    });

    const REPAIR_CATEGORIES = [
        'Roofing', 'Purlins', 'Trusses', 'Ceiling (Exterior)', 'Ceiling (Interior)',
        'Wall (Exterior)', 'Partition', 'Door', 'Windows', 'Flooring', 'Beams / Columns'
    ];

    const [hasRepair, setHasRepair] = useState(null);
    const [repairAssessments, setRepairAssessments] = useState([]);
    const [showRepairModal, setShowRepairModal] = useState(false);

    const [repairRoomFormData, setRepairRoomFormData] = useState({
        building_name: "",
        room_name: "",
        room_length: 9,
        room_width: 7
    });

    const [repairItemsState, setRepairItemsState] = useState({});


    // Integrated Rooms State
    const [roomsData, setRoomsData] = useState([]); 
    const [roomsPage, setRoomsPage] = useState(1);
    const roomsPerPage = 10;

    const [editingBuildingId, setEditingBuildingId] = useState(null);
    const [editingRepairRoomId, setEditingRepairRoomId] = useState(null);

    const years = Array.from({ length: currentYear - 1950 + 1 }, (_, i) => currentYear - i);

    // ── Data Fetching ─────────────────────────────────────────────────────
    const [isReadOnly, setIsReadOnly] = useState(false);
    const allBuildings = buildings;

    useEffect(() => {
        const init = async () => {
            const storedId = localStorage.getItem("schoolId");
            if (!storedId) return;
            setSchoolId(storedId);

            try {
                const draft = await getUnitDraft(8, storedId);
                const resProfile = await fetch(`/api/ph_schools/${storedId}`);
                if (resProfile.ok) {
                    const profile = await resProfile.json();
                    if (profile.exists && profile.data) {
                        setSchoolData(profile.data);
                        if (profile.data.latitude && profile.data.longitude) {
                            setCenterMap([parseFloat(profile.data.latitude), parseFloat(profile.data.longitude)]);
                        }
                    }
                }

                // MASTER PRECEDENCE: Draft > Database
                if (draft) {
                    setCurrentPage(draft.currentPage || 1);
                    setBuildings(draft.buildings || []);
                    setRoomsData(draft.roomsData || []);
                    setRepairAssessments(draft.repairAssessments || []);
                    setSpaces(draft.spaces || []);
                    setHasRepair(draft.hasRepair);
                    setIsReadOnly(false); // Force edit mode for drafts
                    setShowWelcomeBack(true);
                    setTimeout(() => setShowWelcomeBack(false), 3000);
                } else {
                    fetchMasterData(storedId);
                }

                fetchSpaces(storedId);
                fetchBuildingTypes();
                fetchTeachers(storedId);
            } catch (e) {
                console.warn("Could not fetch Unit 8 data", e);
            }
        };
        init();
    }, []);

    const fetchMasterData = async (id) => {
        try {
            const res = await fetch(`/api/ph_schools/unit10/${id}/master`);
            if (res.ok) {
                const json = await res.json();
                if (json.success && json.data) {
                    const { inventory, repairs, isCompleted } = json.data;
                    setBuildings(inventory);
                    const allRooms = [];
                    inventory.forEach(b => {
                        if (b.rooms && Array.isArray(b.rooms)) {
                            b.rooms.forEach(r => {
                                allRooms.push({
                                    id: r.id, building_local_id: b.id, room_name: r.room_name,
                                    grade_level: r.grade_level, advisory_teacher: r.advisory_teacher,
                                    room_length: r.room_length, room_width: r.room_width,
                                    dimension: r.dimension || '', condition: r.condition || 'Good Condition'
                                });
                            });
                        }
                    });
                    setRoomsData(allRooms);
                    const assessments = repairs.map(r => ({
                        id: r.id, roomId: r.building_name + '-' + r.room_name,
                        building_name: r.building_name, room_name: r.room_name,
                        item: r.item_name, oms: r.oms, condition: r.condition,
                        damage_ratio: r.damage_ratio, recommend_action: r.recommended_action,
                        demo_justification: r.demo_justification, remarks: r.remarks
                    }));
                    setRepairAssessments(assessments);
                    if (assessments.length > 0) setHasRepair(true);
                    setIsReadOnly(isCompleted);
                }
            }
        } catch (e) { console.warn("Error fetching master data:", e); }
    };



    const fetchBuildingTypes = async () => {
        try {
            const res = await fetch('/api/reference/building-types');
            if (res.ok) {
                const data = await res.json();
                if (Array.isArray(data) && data.length > 0) {
                    setBuildingTypes(data);
                    localStorage.setItem("nsbi_building_types", JSON.stringify(data));
                }
            }
        } catch (e) {
            console.warn("Could not fetch building types", e);
        }
    };

    const fetchTeachers = async (id) => {
        try {
            const res = await fetch(`/api/unit8/teachers/${id}`);
            if (res.ok) {
                const json = await res.json();
                if (json.success) {
                    setTeachers(json.teachers);
                }
            }
        } catch (e) {
            console.warn("Could not fetch teachers", e);
        }
    };

    const fetchSpaces = async (id) => {
        try {
            const res = await fetch(`/api/ph_schools/unit10/${id}/spaces`);
            if (res.ok) {
                const data = await res.json();
                if (data.success) {
                    setSpaces(data.spaces);
                }
            }
        } catch (e) {
            console.warn("Error fetching spaces:", e);
        }
    };

    // ── Map Click Event Handler ───────────────────────────────────────────
    const MapClickHandler = () => {
        useMapEvents({
            click(e) {
                if (isFormVisible) {
                    setNewSpace(prev => ({
                        ...prev,
                        center_lat: e.latlng.lat,
                        center_lng: e.latlng.lng
                    }));
                }
            },
        });
        return null;
    };

    // ── Calculation Utilities ──────────────────────────────────────────────
    const calculateBounds = (lat, lng, lengthM, widthM) => {
        if (!lat || !lng || !lengthM || !widthM) return null;

        // 1 degree lat = ~111.32 km
        const latDiff = (lengthM / 2) / 111320;
        // 1 degree lng = ~111.32 km * cos(lat)
        const lngDiff = (widthM / 2) / (111320 * Math.cos(lat * Math.PI / 180));

        return [
            [lat - latDiff, lng - lngDiff], // South-West
            [lat + latDiff, lng + lngDiff]  // North-East
        ];
    };

    // ── Saving / Deleting ──────────────────────────────────────────────────
    const handleSaveSpace = async () => {
        if (!newSpace.center_lat || !newSpace.center_lng) {
            alert("Please tap on the map to place the center pin.");
            return;
        }

        try {
            setLoading(true);
            const payload = {
                ...newSpace,
                total_area_sqm: totalAreaSqm,
                iern: schoolData?.iern || null,
            };

            const res = await fetch(`/api/ph_schools/unit10/${schoolId}/spaces`, {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify(payload)
            });

            if (!res.ok) throw new Error("Failed to save space");

            // Update Progress locally if this is the first interaction that completes unit 10
            const stored = localStorage.getItem('quest_progress');
            let progress = stored ? JSON.parse(stored) : { completedUnits: [], xp: 0 };
            if (!progress.completedUnits.includes(8)) {
                progress.completedUnits.push(8); 
                // The dashboard mapped Unit 10 ID to locked array of 9. Let's just update as needed.
                if (!progress.completedUnits.includes(10)) progress.completedUnits.push(10);
                progress.xp += 300;
                localStorage.setItem('quest_progress', JSON.stringify(progress));
            }

            await fetchSpaces(schoolId);
            setIsFormVisible(false);
            setNewSpace({
                space_name: "New Building Area",
                center_lat: null, center_lng: null,
                length_m: 10, width_m: 10
            });
        } catch (err) {
            console.error("Submission failed", err);
            alert("Failed to save space.");
        } finally {
            setLoading(false);
        }
    };

    const handleDelete = async (spaceId) => {
        if (!window.confirm("Delete this space?")) return;
        try {
            const res = await fetch(`/api/ph_schools/unit10/spaces/${spaceId}`, { method: "DELETE" });
            if (res.ok) {
                setSpaces(spaces.filter(s => s.id !== spaceId));
            }
        } catch (e) {
            console.error(e);
        }
    };

    // ── Phase 2 Handlers ──────────────────────────────────────────────────
    const handleSaveBuilding = () => {
        if (!buildingFormData.building_name) {
            alert("Please enter a building name.");
            return;
        }

        const isCondemned = buildingFormData.status === 'For Condemnation' || buildingFormData.status === 'Condemned';
        if (isCondemned) {
            const hasReason = buildingFormData.condemn_age || buildingFormData.condemn_hazard || buildingFormData.condemn_calamity || buildingFormData.condemn_upgrade;
            if (!hasReason) {
                alert("Please select at least one justification for condemnation.");
                return;
            }
        }

        const bId = editingBuildingId || Date.now().toString();
        const newEntry = {
            ...buildingFormData,
            id: bId
        };

        // Automatic Room Generation
        const generatedRooms = [];
        const roomsPerFloor = Math.ceil(buildingFormData.classroom / buildingFormData.storey);
        let roomCount = 0;

        for (let floor = 1; floor <= buildingFormData.storey; floor++) {
            for (let r = 0; r < roomsPerFloor && roomCount < buildingFormData.classroom; r++) {
                roomCount++;
                const roomLetter = String.fromCharCode(65 + r); // A, B, C...
                const roomName = `${buildingFormData.building_name} ${floor}-${roomLetter}`;
                
                generatedRooms.push({
                    id: `${bId}-room-${roomCount}`,
                    building_local_id: bId,
                    building_name: buildingFormData.building_name,
                    room_name: roomName,
                    dimensions: "7x9", 
                    grade_level: "",
                    teacher_id: "",
                    condition: "Good Condition", 
                });
            }
        }

        if (editingBuildingId) {
            setBuildings(buildings.map(b => b.id === editingBuildingId ? newEntry : b));
        } else {
            setBuildings([...buildings, newEntry]);
        }

        // Update roomsData: Add or replace rooms for this building
        setRoomsData(prev => [
            ...prev.filter(r => r.building_local_id !== bId),
            ...generatedRooms
        ]);

        setShowBuildingModal(false);
        setEditingBuildingId(null);
        setBuildingFormData({
            building_name: "", category: "Academic Building", storey: 1, classroom: 1,
            year_completed: currentYear, remarks: "", status: "Good Condition",
            condemn_age: false, condemn_hazard: false, condemn_calamity: false, condemn_upgrade: false
        });
        setTimeout(() => handlePartialSync(), 100);
    };

    const handleEditBuilding = (b) => {
        setBuildingFormData({
            building_name: b.building_name,
            category: b.category,
            storey: b.storey,
            classroom: b.classroom,
            year_completed: b.year_completed,
            remarks: b.remarks || "",
            status: b.status || "Good Condition",
            condemn_age: b.condemn_age || false,
            condemn_hazard: b.condemn_hazard || false,
            condemn_calamity: b.condemn_calamity || false,
            condemn_upgrade: b.condemn_upgrade || false
        });
        setEditingBuildingId(b.id);
        setShowBuildingModal(true);
    };

    const handleDeleteBuilding = (bId) => {
        if (!window.confirm("Delete this building and all its rooms?")) return;
        setBuildings(prev => prev.filter(b => b.id !== bId));
        setRoomsData(prev => prev.filter(r => r.building_local_id !== bId));
    };

    const handleToggleRepairItem = (category) => {
        setRepairItemsState(prev => {
            if (prev[category]) {
                const newState = { ...prev };
                delete newState[category];
                return newState;
            } else {
                return {
                    ...prev,
                    [category]: {
                        oms: "",
                        condition: "Good",
                        damage_ratio: 0,
                        recommend_action: "Routine Repair",
                        demo_justification: "",
                        remarks: ""
                    }
                };
            }
        });
    };

    const handleUpdateRepairItem = (category, field, value) => {
        setRepairItemsState(prev => ({
            ...prev,
            [category]: {
                ...prev[category],
                [field]: value
            }
        }));
    };

    const handleSaveRepairRoom = () => {
        if (!repairRoomFormData.building_name || !repairRoomFormData.room_name) {
            alert("Please provide building and room names.");
            return;
        }

        const selectedCategories = Object.keys(repairItemsState);
        if (selectedCategories.length === 0) {
            alert("Please select at least one item to assess.");
            return;
        }

        // Flattening Logic: one object per checked category
        const roomId = repairRoomFormData.building_name + "-" + repairRoomFormData.room_name;

        const newAssessments = selectedCategories.map(category => ({
            id: roomId + "-" + category.replace(/\s/g, ''),
            roomId: roomId,
            building_name: repairRoomFormData.building_name,
            room_name: repairRoomFormData.room_name,
            room_length: repairRoomFormData.room_length,
            room_width: repairRoomFormData.room_width,
            item: category,
            ...repairItemsState[category]
        }));

        // Always replace existing items for this room (building_name + room_name)
        setRepairAssessments(prev => [...prev.filter(a => a.roomId !== roomId), ...newAssessments]);

        setShowRepairModal(false);
        setEditingRepairRoomId(null);
        setRepairRoomFormData({
            building_name: "",
            room_name: "",
            room_length: 9,
            room_width: 7
        });
        setRepairItemsState({});
        setTimeout(() => handlePartialSync(), 100);
    };

    const handleEditRepairRoom = (roomGroup) => {
        setRepairRoomFormData({
            building_name: roomGroup.building_name,
            room_name: roomGroup.room_name,
            room_length: roomGroup.room_length,
            room_width: roomGroup.room_width
        });

        const reconstructedState = {};
        roomGroup.items.forEach(itm => {
            reconstructedState[itm.item] = {
                made_of: itm.made_of || "",
                condition: itm.condition,
                damage_ratio: itm.damage_ratio || 0,
                recommend_action: itm.recommend_action || "Routine Repair",
                demo_justification: itm.demo_justification || "",
                remarks: itm.remarks || ""
            };
        });
        setRepairItemsState(reconstructedState);
        setEditingRepairRoomId(roomGroup.roomId);
        setShowRepairModal(true);
    };

    const handleDeleteRepairRoom = (roomId) => {
        setRepairAssessments(prev => prev.filter(a => a.roomId !== roomId));
    };

    // Helper to group assessments by room for display
    const groupedRepairs = repairAssessments.reduce((acc, curr) => {
        if (!acc[curr.roomId]) {
            acc[curr.roomId] = {
                roomId: curr.roomId,
                building_name: curr.building_name,
                room_name: curr.room_name,
                room_length: curr.room_length,
                room_width: curr.room_width,
                items: []
            };
        }
        acc[curr.roomId].items.push(curr);
        return acc;
    }, {});
    const groupedRepairsArray = Object.values(groupedRepairs);


    const handlePartialSync = async () => {
        try {
            const inventoryPayload = buildings;
            const repairPayload = repairAssessments.map(a => ({
                building_no: a.building_name,
                room_no: a.room_name,
                item_name: a.item,
                oms: a.oms,
                condition: a.condition,
                damage_ratio: a.damage_ratio,
                recommended_action: a.recommend_action,
                demo_justification: a.demo_justification,
                remarks: a.remarks
            }));
            const build_classrooms_total = roomsData.length;

            await fetch(`/api/save-physical-facilities`, {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({
                    schoolId: schoolId,
                    school_id: schoolId,
                    inventoryEntries: inventoryPayload,
                    rooms: roomsData,
                    repairEntries: repairPayload,
                    build_classrooms_total,
                    isPartial: true // Flag to backend
                })
            });
        } catch (e) {
            console.warn("Partial sync failed", e);
        }
    };

    const handleMasterSubmit = async () => {
        // STRICT VALIDATION: Do not mark Unit 8 as accomplished when there are no buildings registered
        if (!buildings || buildings.length === 0) {
            alert("Error: You must register at least one building before marking Unit 8 as accomplished.");
            return;
        }

        const confirmSubmit = window.confirm("Are you sure you want to finalize and save this entire Unit 8 Audit?");
        if (!confirmSubmit) return;

        try {
            setLoading(true);

            // Phase 2 Step 1 & 2: Building Inventory
            const inventoryPayload = buildings;

            // Phase 2 Step 3: Granular Room Setup
            // roomsData is already flat

            // Phase 2 Step 4: Repair Assessments
            const repairPayload = repairAssessments.map(a => ({
                building_no: a.building_name,
                room_no: a.room_name,
                item_name: a.item,
                oms: a.oms,
                condition: a.condition,
                damage_ratio: a.damage_ratio,
                recommended_action: a.recommend_action,
                demo_justification: a.demo_justification,
                remarks: a.remarks
            }));

            // Phase 3: Demolitions

            // Summary counts for school profile
            const build_classrooms_total = roomsData.length;
            const build_classrooms_new = buildings.filter(b => b.status === "Newly Built").reduce((acc, b) => acc + (parseInt(b.classroom) || 0), 0);
            const build_classrooms_good = buildings.filter(b => b.status === "Good Condition").reduce((acc, b) => acc + (parseInt(b.classroom) || 0), 0);
            const build_classrooms_repair = [...new Set(repairAssessments.map(a => `${a.building_name}-${a.room_name}`))].length;
            const build_classrooms_demolition = buildings
                .filter(b => b.status === "For Condemnation" || b.status === "Condemned")
                .reduce((acc, b) => acc + (parseInt(b.classroom) || 0), 0);

            console.log("--- FINAL PAYLOAD TO BACKEND ---");
            console.log("Inventory:", inventoryPayload);
            console.log("Rooms:", roomsData);
            console.log("Repairs:", repairPayload);

            // Send all data to the backend master endpoint
            const masterRes = await fetch(`/api/save-physical-facilities`, {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({
                    schoolId: schoolId,
                    school_id: schoolId, // Backward fallback
                    inventoryEntries: inventoryPayload,
                    rooms: roomsData,
                    repairEntries: repairPayload,
                    // Classroom profile data
                    build_classrooms_total,
                    build_classrooms_new,
                    build_classrooms_good,
                    build_classrooms_repair,
                    build_classrooms_demolition
                })
            });

            if (!masterRes.ok) {
                const errorData = await masterRes.json().catch(() => null);
                console.error("Master Submission Error Response:", errorData);
                throw new Error("Failed to submit Unit 8 master payload.");
            }

            // Force Unit 8 completion XP if not done
            const stored = localStorage.getItem('quest_progress');
            let progress = stored ? JSON.parse(stored) : { completedUnits: [], xp: 0 };
            if (!progress.completedUnits.includes(8)) {
                progress.completedUnits.push(8);
                progress.xp += 500;
                localStorage.setItem('quest_progress', JSON.stringify(progress));

                // Also notify backend about progress
                fetch('/api/user/progress', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({
                        unitId: 8,
                        schoolId: schoolId,
                        duration_seconds: 0 // Optional
                    })
                }).catch(err => console.error("Failed to sync progress to backend", err));
            }
            
            setShowSuccess(true);
            await clearUnitDraft(8, schoolId);
            // Redirection happens via SuccessModal onClose or we can delay it
            setTimeout(() => {
                navigate("/modular-dashboard");
            }, 3000);

        } catch (err) {
            console.error("Master submission failed", err);
            alert("Failed to submit master payload.");
        } finally {
            setLoading(false);
        }
    };

    const handleBack = () => {
        navigate("/modular-dashboard");
    };

    const handleSaveDraftAndExit = async () => {
        if (!schoolId) return;
        const draftData = {
            currentPage,
            buildings,
            roomsData,
            repairAssessments,
            spaces,
            hasRepair
        };
        await saveUnitDraft(8, schoolId, draftData);
        navigate("/modular-dashboard");
    };

    // ── Summary Dashboard Component ─────────────────────────────────────────
    const SummaryDashboard = () => {
        const totalClassrooms = buildings.reduce((sum, b) => sum + (parseInt(b.classroom) || 0), 0);

        return (
            <div className="min-h-screen bg-gray-50 flex flex-col font-sans overflow-x-hidden selection:bg-indigo-500/30">
                {/* Top Navigation */}
                <header className="px-6 py-4 flex items-center justify-between sticky top-0 bg-gray-50/80 backdrop-blur-md z-50 border-b border-gray-200/50">
                    <div className="flex items-center gap-2">
                        <button onClick={handleBack} className="w-12 h-12 rounded-full bg-white border border-gray-200 flex items-center justify-center text-gray-500 shadow-sm hover:bg-gray-50 hover:scale-105 active:scale-95 transition-all">
                            <FiArrowLeft className="w-6 h-6" />
                        </button>
                    </div>
                    <div className="flex flex-col items-center">
                        <span className="text-[10px] font-black tracking-[0.2em] text-indigo-500 uppercase">Unit 8 Insight</span>
                        <h1 className="font-black text-gray-800 text-lg uppercase tracking-wide">Physical Facilities</h1>
                    </div>
                    <div className="w-12" />
                </header>

                {/* Hero Section */}
                <div className="px-6 pt-8 pb-6 text-center">
                    <motion.div
                        initial={{ scale: 0 }}
                        animate={{ scale: 1 }}
                        className="w-24 h-24 mx-auto mb-4 relative"
                    >
                        <div className="absolute inset-0 bg-indigo-500 rounded-[2rem] rotate-45 opacity-20" />
                        <div className="absolute inset-0 bg-indigo-500 rounded-[2rem] flex items-center justify-center shadow-xl shadow-indigo-200">
                            <span className="text-4xl">🏢</span>
                        </div>
                    </motion.div>
                    <h2 className="text-3xl font-black text-gray-800 tracking-tight">Facilities Audit</h2>
                    <p className="text-gray-500 font-medium mt-2">Verified records as of {new Date().toLocaleDateString()}</p>
                </div>

                <main className="px-6 pb-24 space-y-6 max-w-3xl mx-auto w-full">

                    {/* 1. Top-Level Metric Cards */}
                    <div className="grid grid-cols-2 gap-4">
                        <div className="bg-white rounded-3xl p-5 shadow-sm border border-gray-100 flex flex-col items-center justify-center text-center relative overflow-hidden group">
                            <div className="absolute inset-0 bg-gradient-to-br from-indigo-500/5 to-transparent opacity-0 group-hover:opacity-100 transition-opacity" />
                            <span className="text-4xl font-black text-indigo-600 mb-2">{spaces.length}</span>
                            <span className="text-xs font-bold text-gray-400 uppercase tracking-wider">Buildable Spaces</span>
                        </div>
                        <div className="bg-white rounded-3xl p-5 shadow-sm border border-gray-100 flex flex-col items-center justify-center text-center relative overflow-hidden group">
                            <div className="absolute inset-0 bg-gradient-to-br from-teal-500/5 to-transparent opacity-0 group-hover:opacity-100 transition-opacity" />
                            <span className="text-4xl font-black text-teal-600 mb-2">{totalClassrooms}</span>
                            <span className="text-xs font-bold text-gray-400 uppercase tracking-wider">Usable Rooms</span>
                        </div>
                        <div className="bg-white rounded-3xl p-5 shadow-sm border border-gray-100 flex flex-col items-center justify-center text-center relative overflow-hidden group">
                            <div className="absolute inset-0 bg-gradient-to-br from-amber-500/5 to-transparent opacity-0 group-hover:opacity-100 transition-opacity" />
                            <span className="text-4xl font-black text-amber-500 mb-2">{groupedRepairsArray.length}</span>
                            <span className="text-xs font-bold text-gray-400 uppercase tracking-wider">For Repair</span>
                        </div>
                        <div className="bg-white rounded-3xl p-5 shadow-sm border border-gray-100 flex flex-col items-center justify-center text-center relative overflow-hidden group">
                            <div className="absolute inset-0 bg-gradient-to-br from-rose-500/5 to-transparent opacity-0 group-hover:opacity-100 transition-opacity" />
                            <span className="text-4xl font-black text-rose-600 mb-2">
                                {buildings.filter(b => b.status === "For Condemnation" || b.status === "Condemned").length}
                            </span>
                            <span className="text-xs font-bold text-gray-400 uppercase tracking-wider">For Demolition</span>
                        </div>
                    </div>

                    {/* 2. Phase 1: Buildable Space Map View */}
                    <div className="bg-white rounded-[2rem] p-6 shadow-sm border border-gray-100 relative overflow-hidden">
                        <div className="absolute top-0 right-0 w-32 h-32 bg-gradient-to-br from-indigo-500/5 to-transparent rounded-full -mr-16 -mt-16 pointer-events-none" />
                        <h3 className="text-lg font-black text-gray-800 mb-4 flex items-center gap-2">
                            <span className="w-8 h-8 rounded-lg bg-indigo-100 text-indigo-600 flex items-center justify-center"><FiMapPin /></span>
                            Phase 1: Buildable Spaces
                        </h3>
                        <div className="h-[250px] rounded-2xl overflow-hidden shadow-inner mb-4 bg-gray-50 border border-gray-200">
                            {centerMap ? (
                                <MapContainer center={centerMap} zoom={18} scrollWheelZoom={false} dragging={false} doubleClickZoom={false} zoomControl={false} className="h-full w-full">
                                    <TileLayer url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png" />
                                    <RecenterMap center={centerMap} />
                                    {spaces.map((s, idx) => {
                                        const bounds = calculateBounds(parseFloat(s.center_lat), parseFloat(s.center_lng), parseFloat(s.length_m) || 0, parseFloat(s.width_m) || 0);
                                        return bounds ? (
                                            <Rectangle key={'ro-' + idx} bounds={bounds} pathOptions={{ color: 'blue', weight: 3, fillOpacity: 0.2 }} />
                                        ) : null;
                                    })}
                                </MapContainer>
                            ) : (
                                <div className="w-full h-full flex items-center justify-center text-gray-400 font-medium">Map unavailable</div>
                            )}
                        </div>
                        <div className="space-y-3">
                            {spaces.map(s => (
                                <div key={s.id} className="bg-gray-50 p-4 rounded-2xl border border-gray-100 flex justify-between items-center group hover:border-indigo-200 transition-colors">
                                    <div>
                                        <h4 className="font-bold text-gray-800">{s.space_name}</h4>
                                        <p className="text-xs text-gray-500 font-medium mt-1">{s.length_m}m &times; {s.width_m}m</p>
                                    </div>
                                    <span className="text-indigo-600 font-black bg-indigo-100/50 px-3 py-1 rounded-lg border border-indigo-100">{parseFloat(s.total_area_sqm).toFixed(1)} m&sup2;</span>
                                </div>
                            ))}
                            {spaces.length === 0 && <p className="text-gray-400 font-medium italic text-sm text-center py-2">No spaces recorded.</p>}
                        </div>
                    </div>

                    {/* 3. Phase 2: Inventory Breakdown */}
                    <div className="space-y-6">
                        <h3 className="text-xl font-black text-gray-800 px-2">Phase 2: Inventory Breakdown</h3>

                        {/* Registered Buildings */}
                        <div className="bg-white rounded-[2rem] p-6 shadow-sm border border-gray-100 relative overflow-hidden">
                            <div className="absolute top-0 right-0 w-32 h-32 bg-gradient-to-br from-indigo-500/5 to-transparent rounded-full -mr-16 -mt-16 pointer-events-none" />
                            <h4 className="text-lg font-black text-gray-800 mb-4 flex items-center gap-2">
                                <span className="w-8 h-8 rounded-lg bg-indigo-100 text-indigo-600 flex items-center justify-center">🏫</span>
                                Registered Buildings
                            </h4>
                            <div className="space-y-3">
                                {buildings.map(b => (
                                    <div key={b.id} className="bg-gray-50 p-4 rounded-2xl border border-gray-100">
                                        <div className="flex justify-between items-start">
                                            <h5 className="font-black text-gray-800">{b.building_name}</h5>
                                            <span className="px-2 py-0.5 bg-white border border-gray-100 rounded-md text-[10px] font-black text-gray-400 uppercase tracking-widest">{b.category}</span>
                                        </div>
                                        <div className="mt-2 flex flex-wrap gap-2">
                                            <span className="px-3 py-1 bg-white border border-gray-200 rounded-lg text-xs font-bold text-gray-600 shadow-sm">{b.storey} Storey(s)</span>
                                            <span className="px-3 py-1 bg-white border border-gray-200 rounded-lg text-xs font-bold text-gray-600 shadow-sm">{b.classroom} Classrooms</span>
                                        </div>
                                    </div>
                                ))}
                                {buildings.length === 0 && <p className="text-gray-400 font-medium italic text-sm text-center py-2">No structures recorded.</p>}
                            </div>
                        </div>
                    </div>

                    {/* 4. Action Items */}
                    <div className="space-y-6">
                        <h3 className="text-xl font-black text-gray-800 px-2 mt-4">Required Interventions</h3>

                        {/* Repairs */}
                        <div className="bg-white rounded-[2rem] p-6 shadow-sm border border-amber-100 relative overflow-hidden">
                            <div className="absolute top-0 right-0 w-32 h-32 bg-gradient-to-br from-amber-500/5 to-transparent rounded-full -mr-16 -mt-16 pointer-events-none" />
                            <h4 className="text-lg font-black text-gray-800 mb-4 flex items-center gap-2">
                                <span className="w-8 h-8 rounded-lg bg-amber-100 text-amber-600 flex items-center justify-center">🛠️</span>
                                Repair Assessments
                            </h4>
                            <div className="space-y-3">
                                {groupedRepairsArray.map(r => (
                                    <div key={r.roomId} className="bg-amber-50/30 p-4 rounded-2xl border border-amber-100/50">
                                        <h5 className="font-black text-gray-800">{r.building_name} &bull; <span className="text-amber-600">{r.room_name}</span></h5>
                                        <p className="text-xs font-bold text-gray-400 mt-1 mb-3">Room Dimensions: {r.room_length}m &times; {r.room_width}m</p>
                                        <div className="bg-white p-3 rounded-xl border border-gray-100 text-sm shadow-sm">
                                            <span className="font-bold text-gray-700 block mb-1">Damaged Items:</span>
                                            <p className="text-gray-600 font-medium">
                                                {r.items.map(i => `${i.item} (${i.recommend_action === 'Routine Repair' ? i.damage_ratio + '%' : i.recommend_action})`).join(', ')}
                                            </p>
                                        </div>
                                    </div>
                                ))}
                                {groupedRepairsArray.length === 0 && <p className="text-gray-400 font-medium italic text-sm text-center py-2">No repairs needed.</p>}
                            </div>
                        </div>

                        {/* Demolitions */}
                        <div className="bg-white rounded-[2rem] p-6 shadow-sm border border-rose-100 relative overflow-hidden">
                            <div className="absolute top-0 right-0 w-32 h-32 bg-gradient-to-br from-rose-500/5 to-transparent rounded-full -mr-16 -mt-16 pointer-events-none" />
                            <h4 className="text-lg font-black text-gray-800 mb-4 flex items-center gap-2">
                                <span className="w-8 h-8 rounded-lg bg-rose-100 text-rose-600 flex items-center justify-center">🚜</span>
                                Slated for Demolition
                            </h4>
                            <div className="space-y-3">
                                {buildings.filter(b => b.status === "For Condemnation" || b.status === "Condemned").map(b => (
                                    <div key={b.id} className="bg-rose-50/30 p-4 rounded-2xl border border-rose-100/50">
                                        <h5 className="font-black text-gray-800 text-lg mb-1">{b.building_name}</h5>
                                        <div className="flex gap-2 mb-3">
                                            <span className="text-[10px] font-black bg-white/50 px-2 py-0.5 rounded border border-rose-100 text-rose-600">{b.storey} Storey(s)</span>
                                            <span className="text-[10px] font-black bg-white/50 px-2 py-0.5 rounded border border-rose-100 text-rose-600">{b.classroom} Classrooms</span>
                                        </div>
                                        <div className="flex flex-wrap gap-2">
                                            {b.condemn_age && <span className="bg-white border border-rose-100 text-rose-600 text-[10px] uppercase tracking-wider font-black px-2 py-1 rounded-lg">Age/Dilapidation</span>}
                                            {b.condemn_hazard && <span className="bg-white border border-rose-100 text-rose-600 text-[10px] uppercase tracking-wider font-black px-2 py-1 rounded-lg">Safety Hazard</span>}
                                            {b.condemn_calamity && <span className="bg-white border border-rose-100 text-rose-600 text-[10px] uppercase tracking-wider font-black px-2 py-1 rounded-lg">Calamity Damage</span>}
                                            {b.condemn_upgrade && <span className="bg-white border border-rose-100 text-rose-600 text-[10px] uppercase tracking-wider font-black px-2 py-1 rounded-lg">Site Upgrade</span>}
                                        </div>
                                    </div>
                                ))}
                                {buildings.filter(b => b.status === "For Condemnation" || b.status === "Condemned").length === 0 && (
                                    <p className="text-gray-400 font-medium italic text-sm text-center py-2">No demolitions recorded.</p>
                                )}
                            </div>
                        </div>
                    </div>

                    {/* 5. Unlock Action */}
                    <div className="pt-6">
                        <p className="text-center text-xs font-bold text-gray-400 mt-4 mb-20">Your Physical Facilities Audit data is saved and verified.</p>
                    </div>
                </main>
                
                <footer className="fixed bottom-0 left-0 w-full p-6 pb-10 bg-white/80 backdrop-blur-md border-t border-slate-100 flex justify-center z-40">
                    <div className="w-full max-w-sm flex gap-3 pointer-events-auto">
                        <button onClick={() => setShowDraftModal(true)} className="w-16 h-16 rounded-3xl bg-gray-100 flex items-center justify-center text-gray-400 hover:text-gray-900 active:scale-95 transition-all outline-none">
                             <FiSave className="w-6 h-6" />
                        </button>
                        <button
                            onClick={() => setIsReadOnly(false)}
                            className="flex-1 py-5 rounded-[2rem] bg-indigo-600 text-white font-black text-xl shadow-xl shadow-indigo-100/50 hover:bg-indigo-700 active:scale-95 transition-all flex items-center justify-center gap-3"
                        >
                            <FiUnlock className="w-6 h-6" />
                            <span>Unlock to Edit Architecture</span>
                        </button>
                    </div>
                </footer>
            </div>
        );
    };

    // ── Render Wizard ─────────────────────────────────────────────────────
    if (isReadOnly) {
        return <SummaryDashboard />;
    }

    return (
        <div className="min-h-screen bg-gray-50 flex flex-col font-sans overflow-x-hidden pb-10">
            {/* Welcome Back Toast */}
            <AnimatePresence>
                {showWelcomeBack && (
                    <motion.div initial={{ opacity: 0, y: -20 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, scale: 0.9 }}
                        className="fixed top-20 left-1/2 -translate-x-1/2 bg-gray-900 text-white px-5 py-2.5 rounded-full shadow-2xl text-[13px] font-bold flex items-center gap-2 z-[60]">
                        <div className="w-2 h-2 bg-green-400 rounded-full animate-ping" />
                        Recovered your draft!
                    </motion.div>
                )}
            </AnimatePresence>
            {/* Header / Nav */}
            <header className="sticky top-0 z-50 bg-white shadow-sm px-4 py-3">
                <div className="max-w-3xl mx-auto flex items-center justify-between">
                    <div className="flex items-center gap-2">
                        <button onClick={handleBack} className="p-2 rounded-full hover:bg-gray-100 text-gray-400">
                            <FiArrowLeft className="w-6 h-6" />
                        </button>
                    </div>
                    <div className="flex flex-col items-center">
                        <h1 className="font-bold text-gray-800 text-xl">Unit 8 Audit</h1>
                        <span className="text-[10px] font-black text-indigo-500 uppercase tracking-widest">Step {currentPage} of 4</span>
                    </div>
                    <div className="w-10"></div>
                </div>
                {/* Visual Progress Bar */}
                <div className="max-w-3xl mx-auto mt-2 h-1.5 bg-gray-100 rounded-full overflow-hidden flex gap-1">
                    {[1, 2, 3, 4].map(step => (
                        <div
                            key={step}
                            className={`flex-1 h-full transition-all duration-500 ${currentPage >= step ? "bg-indigo-500" : "bg-gray-200"}`}
                        />
                    ))}
                </div>
            </header>

            <main className="flex-1 w-full max-w-3xl mx-auto p-4 lg:p-6 flex flex-col pt-8">

                {currentPage === 1 && (
                    <motion.div initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }}>
                        <h2 className="text-3xl font-black text-gray-800 tracking-tight leading-tight mb-2">
                            Visual Multi-Space Builder 🏗️
                        </h2>
                        <p className="text-gray-500 mb-6 font-medium">Draw and record buildable spaces for the school campus footprint.</p>

                        {/* Map Display area */}
                        <div className="bg-white p-3 rounded-2xl shadow-sm border border-gray-200 mb-6 relative overflow-hidden z-0">
                            <div className="h-[400px] rounded-xl overflow-hidden shadow-inner">
                                {centerMap && (
                                    <MapContainer center={centerMap} zoom={18} scrollWheelZoom={true} className="h-full w-full">
                                        <TileLayer
                                            attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
                                            url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
                                            maxZoom={20}
                                        />
                                        <MapClickHandler />
                                        <RecenterMap center={centerMap} />

                                        {/* Render existing spaces */}
                                        {spaces.map((s, idx) => {
                                            const b = calculateBounds(parseFloat(s.center_lat), parseFloat(s.center_lng), parseFloat(s.length_m), parseFloat(s.width_m));
                                            if (!b) return null;
                                            return (
                                                <React.Fragment key={idx}>
                                                    <Rectangle bounds={b} pathOptions={{ color: 'blue', weight: 2, fillOpacity: 0.2 }} />
                                                    <Marker position={[s.center_lat, s.center_lng]}>
                                                        <Popup>{s.space_name} ({s.total_area_sqm} sqm)</Popup>
                                                    </Marker>
                                                </React.Fragment>
                                            );
                                        })}

                                         {/* Render new drawing space */}
                                         {newSpace.center_lat && newSpace.center_lng && isFormVisible && (() => {
                                             const b = calculateBounds(newSpace.center_lat, newSpace.center_lng, newSpace.length_m || 0, newSpace.width_m || 0);
                                             if (!b) return null;
                                             return (
                                                 <>
                                                     <Rectangle 
                                                         bounds={b} 
                                                         pathOptions={{ color: 'emerald', weight: 4, fillOpacity: 0.4 }} 
                                                     />
                                                     <Marker position={[newSpace.center_lat, newSpace.center_lng]}>
                                                         <Popup>Target Location</Popup>
                                                     </Marker>
                                                 </>
                                             );
                                         })()}
                                    </MapContainer>
                                )}
                            </div>
                        </div>

                        {/* Form or Add Button */}
                        <AnimatePresence mode="wait">
                            {!isFormVisible ? (
                                <motion.button
                                    key="addbtn"
                                    initial={{ opacity: 0, scale: 0.9 }}
                                    animate={{ opacity: 1, scale: 1 }}
                                    exit={{ opacity: 0, scale: 0.9 }}
                                    onClick={() => setIsFormVisible(true)}
                                    className="bg-emerald-500 w-full py-4 rounded-2xl text-white font-black text-lg border-b-[6px] border-emerald-700 active:border-b-0 active:translate-y-[6px] shadow-lg flex justify-center items-center gap-2 mb-8 transition-all hover:bg-emerald-400"
                                >
                                    <FiPlus className="w-6 h-6" /> Add New Space
                                </motion.button>
                            ) : (
                                <motion.div
                                    key="form"
                                    initial={{ opacity: 0, y: 20 }}
                                    animate={{ opacity: 1, y: 0 }}
                                    exit={{ opacity: 0, y: -20 }}
                                    className="bg-white p-5 rounded-3xl shadow-lg border border-gray-100 mb-8"
                                >
                                    <div className="flex justify-between items-center mb-4">
                                        <h3 className="font-black text-xl text-gray-800">New Space Details</h3>
                                        <button onClick={() => setIsFormVisible(false)} className="text-gray-400 hover:text-gray-700"><FiX className="w-6 h-6" /></button>
                                    </div>

                                    <p className="text-sm font-bold text-amber-600 mb-4 bg-amber-50 p-3 rounded-lg flex items-center gap-2">
                                        <FiMapPin className="shrink-0" />
                                        {newSpace.center_lat ? "Pin placed! Adjust size." : "Tap on the map above to select the center location!"}
                                    </p>

                                    <div className="space-y-4">
                                        <div>
                                            <label className="text-sm font-bold text-gray-500 ml-2">Space Name / ID</label>
                                            <input type="text" value={newSpace.space_name} onChange={(e) => setNewSpace({ ...newSpace, space_name: e.target.value })}
                                                className="w-full bg-gray-50 border-2 border-gray-200 mt-1 rounded-2xl px-4 py-3 text-lg font-bold text-gray-700 outline-none focus:border-emerald-500 transition-all" />
                                        </div>

                                        <div className="flex gap-4">
                                            <div className="flex-1">
                                                <label className="text-sm font-bold text-gray-500 ml-2">Length (meters)</label>
                                                <input type="number" value={newSpace.length_m} onChange={(e) => setNewSpace({ ...newSpace, length_m: parseFloat(e.target.value) || 0 })}
                                                    className="w-full bg-gray-50 border-2 border-gray-200 mt-1 rounded-2xl px-4 py-3 text-lg font-bold text-gray-700 outline-none focus:border-emerald-500 transition-all text-center" />
                                            </div>
                                            <div className="flex-1">
                                                <label className="text-sm font-bold text-gray-500 ml-2">Width (meters)</label>
                                                <input type="number" value={newSpace.width_m} onChange={(e) => setNewSpace({ ...newSpace, width_m: parseFloat(e.target.value) || 0 })}
                                                    className="w-full bg-gray-50 border-2 border-gray-200 mt-1 rounded-2xl px-4 py-3 text-lg font-bold text-gray-700 outline-none focus:border-emerald-500 transition-all text-center" />
                                            </div>
                                        </div>

                                        <div className="bg-emerald-50 p-4 rounded-2xl border-2 border-emerald-100 flex justify-between items-center mt-4">
                                            <span className="font-bold text-emerald-800">Computed Area:</span>
                                            <span className="text-3xl font-black text-emerald-600">{totalAreaSqm.toFixed(2)} m&sup2;</span>
                                        </div>
                                    </div>

                                    <button onClick={handleSaveSpace} disabled={loading || !newSpace.center_lat}
                                        className="w-full mt-6 py-4 rounded-2xl text-white font-black text-lg bg-indigo-500 border-b-[6px] border-indigo-700 active:border-b-0 active:translate-y-[6px] transition-all disabled:opacity-50 disabled:bg-gray-300 disabled:border-gray-400 shadow-xl shadow-indigo-200/50">
                                        {loading ? "Saving..." : "Save space configuration ✓"}
                                    </button>
                                </motion.div>
                            )}
                        </AnimatePresence>

                        {/* List of Saved spaces */}
                        {spaces.length > 0 && (
                            <div className="mt-4">
                                <h3 className="font-black text-xl text-gray-800 mb-4 px-2">Saved Spaces</h3>
                                <div className="space-y-3">
                                    {spaces.map(s => (
                                        <div key={s.id} className="bg-white p-4 rounded-2xl shadow-sm border border-gray-100 flex justify-between items-center">
                                            <div>
                                                <h4 className="font-bold text-lg text-gray-800">{s.space_name}</h4>
                                                <p className="text-sm text-gray-500 font-medium">{s.length_m}m &times; {s.width_m}m &nbsp;&bull;&nbsp; <span className="text-emerald-600 font-bold">{parseFloat(s.total_area_sqm).toFixed(2)} m&sup2;</span></p>
                                            </div>
                                            <button onClick={() => handleDelete(s.id)} className="p-3 bg-rose-50 text-rose-500 rounded-xl hover:bg-rose-100 transition-colors">
                                                <FiTrash2 className="w-5 h-5" />
                                            </button>
                                        </div>
                                    ))}
                                </div>
                            </div>
                        )}
                    </motion.div>
                )}

                {/* ────────────────────────────────────────────────────────
                    PHASE 2: Register Building
                    ──────────────────────────────────────────────────────── */}
                {currentPage === 2 && (
                    <motion.div initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }}>
                        <h2 className="text-3xl font-black text-gray-800 tracking-tight leading-tight mb-2">
                            Register Building 🏢
                        </h2>
                        <p className="text-gray-500 mb-6 font-medium">Log the physical structures on your campus.</p>

                        {/* Inventory Area */}
                        <div className="space-y-6">
                            {/* Card List */}
                            {allBuildings.length > 0 && (
                                <div className="space-y-4">
                                    {allBuildings.map(b => (
                                        <div key={b.id} className="bg-white p-5 rounded-3xl shadow-sm border-2 border-gray-100 flex justify-between items-center">
                                            <div>
                                                <h4 className="font-black text-xl text-gray-800">{b.building_name}</h4>
                                                <div className="flex gap-2 mt-1">
                                                    <span className={`text-[10px] font-black px-2 py-0.5 rounded-full uppercase tracking-wider ${b.status === 'Newly Built' ? 'bg-emerald-100 text-emerald-700' : 'bg-blue-100 text-blue-700'}`}>
                                                        {b.status}
                                                    </span>
                                                </div>
                                                <p className="text-sm font-bold text-gray-500 mt-1">{b.category} &bull; {b.storey} Storey &bull; {b.classroom} Rooms</p>
                                            </div>
                                            <div className="flex flex-col gap-2">
                                                <button onClick={() => handleEditBuilding(b)} className="p-3 bg-indigo-50 text-indigo-500 rounded-xl hover:bg-indigo-100 transition-colors">
                                                    <FiEdit2 className="w-5 h-5" />
                                                </button>
                                                <button onClick={() => handleDeleteBuilding(b.id)} className="p-3 bg-rose-50 text-rose-500 rounded-xl hover:bg-rose-100 transition-colors">
                                                    <FiTrash2 className="w-5 h-5" />
                                                </button>
                                            </div>
                                        </div>
                                    ))}
                                </div>
                            )}

                            {/* Add Button */}
                            {!showBuildingModal ? (
                                <motion.button
                                    initial={{ opacity: 0, scale: 0.9 }}
                                    animate={{ opacity: 1, scale: 1 }}
                                    onClick={() => setShowBuildingModal(true)}
                                    className="bg-indigo-50 w-full py-4 rounded-2xl text-indigo-600 font-black text-lg border-2 border-indigo-200 border-dashed hover:bg-indigo-100 hover:border-indigo-300 transition-all flex justify-center items-center gap-2"
                                >
                                    <FiPlus className="w-6 h-6" /> Register Building
                                </motion.button>
                            ) : (
                                /* Form Area */
                                <motion.div
                                    initial={{ opacity: 0, y: 20 }}
                                    animate={{ opacity: 1, y: 0 }}
                                    className="bg-white p-6 rounded-[2rem] shadow-xl border border-gray-200"
                                >
                                    <div className="flex justify-between items-center mb-6 border-b-2 border-gray-50 pb-4">
                                        <h3 className="font-black text-2xl text-gray-800">Building Details</h3>
                                        <button onClick={() => setShowBuildingModal(false)} className="text-gray-400 hover:text-gray-700 bg-gray-50 p-2 rounded-full">
                                            <FiX className="w-6 h-6" />
                                        </button>
                                    </div>

                                    <div className="space-y-5">
                                        <div>
                                            <label className="text-sm font-bold text-gray-500 ml-2">Building Name</label>
                                            <input 
                                                type="text" 
                                                value={buildingFormData.building_name} 
                                                onChange={(e) => setBuildingFormData({ ...buildingFormData, building_name: e.target.value })}
                                                className="w-full bg-gray-50 border-2 border-gray-200 mt-1 rounded-2xl px-4 py-3 text-lg font-bold text-gray-700 outline-none focus:border-indigo-500 transition-all placeholder-gray-300" 
                                                placeholder="e.g. Marcos Type Bldg" 
                                            />
                                        </div>

                                        <div className={`relative ${isBuildingDropdownOpen ? 'z-50' : 'z-0'}`}>
                                            <label className="text-sm font-bold text-gray-500 ml-2">Building Category</label>
                                            <div className="relative mt-1">
                                                <div className="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none">
                                                    <FiSearch className="text-gray-400 w-5 h-5" />
                                                </div>
                                                <input
                                                    type="text"
                                                    placeholder="Search building type..."
                                                    value={isBuildingDropdownOpen ? buildingSearch : buildingFormData.category}
                                                    onFocus={() => {
                                                        setIsBuildingDropdownOpen(true);
                                                        setBuildingSearch("");
                                                    }}
                                                    onChange={(e) => {
                                                        setBuildingSearch(e.target.value);
                                                        setBuildingFormData(prev => ({ ...prev, category: e.target.value }));
                                                    }}
                                                    className="w-full bg-gray-50 border-2 border-gray-200 rounded-2xl pl-11 pr-12 py-4 text-lg font-bold text-gray-700 outline-none focus:border-indigo-500 focus:bg-white transition-all placeholder-gray-300 shadow-sm"
                                                />
                                                <div
                                                    className="absolute inset-y-0 right-0 pr-4 flex items-center cursor-pointer text-gray-400 hover:text-indigo-500"
                                                    onClick={() => setIsBuildingDropdownOpen(!isBuildingDropdownOpen)}
                                                >
                                                    <FiChevronDown className={`w-6 h-6 transition-transform duration-300 ${isBuildingDropdownOpen ? 'rotate-180' : ''}`} />
                                                </div>

                                                <AnimatePresence>
                                                    {isBuildingDropdownOpen && (
                                                        <>
                                                            <motion.div
                                                                initial={{ opacity: 0, y: -10, scale: 0.95 }}
                                                                animate={{ opacity: 1, y: 0, scale: 1 }}
                                                                exit={{ opacity: 0, y: -10, scale: 0.95 }}
                                                                className="absolute z-[100] w-full mt-2 bg-white border-2 border-gray-100 rounded-3xl shadow-2xl max-h-72 overflow-y-auto overflow-x-hidden py-2"
                                                            >
                                                                {(buildingSearch ? buildingTypes.filter(t => t.toLowerCase().includes(buildingSearch.toLowerCase())) : buildingTypes).map(type => (
                                                                    <button
                                                                        key={type}
                                                                        type="button"
                                                                        onClick={() => {
                                                                            setBuildingFormData({ ...buildingFormData, category: type });
                                                                            setBuildingSearch(type);
                                                                            setIsBuildingDropdownOpen(false);
                                                                        }}
                                                                        className={`w-full text-left px-6 py-4 font-bold text-gray-700 transition-all border-b border-gray-50 last:border-0 hover:bg-indigo-50 hover:pl-8 flex items-center justify-between ${buildingFormData.category === type ? 'bg-indigo-50 text-indigo-600' : ''}`}
                                                                    >
                                                                        <span>{type}</span>
                                                                        {buildingFormData.category === type && <FiCheck className="w-5 h-5" />}
                                                                    </button>
                                                                ))}
                                                                <div className="px-6 py-8 text-center text-gray-400">
                                                                    {buildingTypes.length === 0 ? (
                                                                        <>
                                                                            <div className="w-8 h-8 border-4 border-indigo-500 border-t-transparent rounded-full animate-spin mx-auto mb-2"></div>
                                                                            <p className="italic font-medium">Fetching building types...</p>
                                                                        </>
                                                                    ) : (buildingSearch && buildingTypes.filter(t => t.toLowerCase().includes(buildingSearch.toLowerCase())).length === 0) ? (
                                                                        <>
                                                                            <FiSearch className="w-10 h-10 mx-auto mb-2 opacity-20" />
                                                                            <p className="italic font-medium">No matching building types found</p>
                                                                        </>
                                                                    ) : null}
                                                                </div>
                                                            </motion.div>
                                                            <div className="fixed inset-0 z-40" onClick={() => setIsBuildingDropdownOpen(false)}></div>
                                                        </>
                                                    )}
                                                </AnimatePresence>
                                            </div>
                                        </div>

                                        <div className="flex gap-4">
                                            <div className="flex-1">
                                                <label className="text-sm font-bold text-gray-500 ml-2">Storeys</label>
                                                <input 
                                                    type="text" 
                                                    inputMode="numeric"
                                                    value={buildingFormData.storey} 
                                                    onChange={(e) => {
                                                        const val = e.target.value.replace(/[^0-9]/g, '').replace(/^0+/, '');
                                                        setBuildingFormData({ ...buildingFormData, storey: (val === '' || val === '0') ? 1 : parseInt(val) });
                                                    }}
                                                    className="w-full bg-gray-50 border-2 border-gray-200 mt-1 rounded-2xl px-4 py-3 text-lg font-bold text-gray-700 outline-none focus:border-indigo-500 transition-all text-center" 
                                                />
                                            </div>
                                            <div className="flex-1">
                                                <label className="text-sm font-bold text-gray-500 ml-2">Classrooms</label>
                                                <input 
                                                    type="text" 
                                                    inputMode="numeric"
                                                    value={buildingFormData.classroom} 
                                                    onChange={(e) => {
                                                        const val = e.target.value.replace(/[^0-9]/g, '').replace(/^0+/, '');
                                                        setBuildingFormData({ ...buildingFormData, classroom: (val === '' || val === '0') ? 1 : parseInt(val) });
                                                    }}
                                                    className="w-full bg-gray-50 border-2 border-gray-200 mt-1 rounded-2xl px-4 py-3 text-lg font-bold text-gray-700 outline-none focus:border-indigo-500 transition-all text-center" 
                                                />
                                            </div>
                                        </div>

                                        <div>
                                            <label className="text-sm font-bold text-gray-500 ml-2">Year Completed</label>
                                            <select 
                                                value={buildingFormData.year_completed} 
                                                onChange={(e) => setBuildingFormData({ ...buildingFormData, year_completed: parseInt(e.target.value) })}
                                                className="w-full bg-gray-50 border-2 border-gray-200 mt-1 rounded-2xl px-4 py-3 text-lg font-bold text-gray-700 outline-none focus:border-indigo-500 transition-all appearance-none cursor-pointer"
                                            >
                                                {years.map(y => <option key={y} value={y}>{y}</option>)}
                                            </select>
                                        </div>

                                        <div className="flex gap-4">
                                            <div className="flex-1">
                                                <label className="text-sm font-bold text-gray-500 ml-2 mb-1 block">Building Status</label>
                                                <select 
                                                    value={buildingFormData.status} 
                                                    onChange={(e) => setBuildingFormData({ ...buildingFormData, status: e.target.value })}
                                                    className="w-full bg-gray-50 border-2 border-gray-200 rounded-2xl px-4 py-3 text-lg font-bold text-gray-700 outline-none focus:border-indigo-500 transition-all cursor-pointer"
                                                >
                                                    <option value="Newly Built">Newly Built</option>
                                                    <option value="Good Condition">Good Condition</option>
                                                    <option value="For Major Repairs">For Major Repairs</option>
                                                    <option value="For Minor Repairs">For Minor Repairs</option>
                                                    <option value="For Condemnation">For Condemnation</option>
                                                    <option value="Condemned">Condemned</option>
                                                </select>
                                            </div>
                                        </div>

                                        {(buildingFormData.status === 'For Condemnation' || buildingFormData.status === 'Condemned') && (
                                            <div className="p-5 bg-rose-50 rounded-2xl border-2 border-rose-100 space-y-4">
                                                <h4 className="text-sm font-black text-rose-600 uppercase tracking-widest flex items-center gap-2">
                                                    <FiAlertTriangle className="w-4 h-4" /> Justification for Condemnation
                                                </h4>
                                                <div className="grid grid-cols-1 gap-3">
                                                    {[
                                                        { id: 'condemn_age', label: 'Age / Dilapidation', icon: <FiClock /> },
                                                        { id: 'condemn_hazard', label: 'Safety Hazard', icon: <FiAlertOctagon /> },
                                                        { id: 'condemn_calamity', label: 'Calamity Damage', icon: <FiCloudLightning /> },
                                                        { id: 'condemn_upgrade', label: 'Site Upgrade / Repurposing', icon: <FiTrendingUp /> }
                                                    ].map(item => (
                                                        <button
                                                            key={item.id}
                                                            onClick={() => setBuildingFormData({ ...buildingFormData, [item.id]: !buildingFormData[item.id] })}
                                                            className={`py-3 px-4 rounded-xl font-bold text-sm border-2 text-left flex items-center justify-between transition-all ${buildingFormData[item.id] ? 'bg-white border-rose-400 text-rose-700 shadow-sm' : 'bg-rose-50/50 border-rose-100 text-rose-300 hover:bg-white hover:border-rose-200'}`}
                                                        >
                                                            <span className="flex items-center gap-2">{item.icon} {item.label}</span>
                                                            <div className={`w-5 h-5 rounded-md border-2 flex items-center justify-center ${buildingFormData[item.id] ? 'bg-rose-500 border-rose-500 text-white' : 'border-rose-200'}`}>
                                                                {buildingFormData[item.id] && <FiCheck className="w-3 h-3" />}
                                                            </div>
                                                        </button>
                                                    ))}
                                                </div>
                                            </div>
                                        )}

                                        <div>
                                            <label className="text-sm font-bold text-gray-500 ml-2">Remarks</label>
                                            <textarea 
                                                value={buildingFormData.remarks} 
                                                onChange={(e) => setBuildingFormData({ ...buildingFormData, remarks: e.target.value })}
                                                className="w-full bg-gray-50 border-2 border-gray-200 mt-1 rounded-2xl px-4 py-3 text-lg font-bold text-gray-700 outline-none focus:border-indigo-500 transition-all min-h-[100px]" 
                                                placeholder="Optional notes..."
                                            ></textarea>
                                        </div>

                                        <button 
                                            onClick={handleSaveBuilding}
                                            className="w-full mt-4 py-4 rounded-2xl text-white font-black text-lg bg-indigo-500 border-b-[6px] border-indigo-700 active:border-b-0 active:translate-y-[6px] transition-all shadow-xl shadow-indigo-200/50"
                                        >
                                            Save Building
                                        </button>
                                    </div>
                                </motion.div>
                            )}
                        </div>
                    </motion.div>
                )}

                {/* ────────────────────────────────────────────────────────
                    PHASE 2: Granular Room Setup
                    ──────────────────────────────────────────────────────── */}
                {currentPage === 3 && (
                    <motion.div initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }}>
                        <h2 className="text-3xl font-black text-gray-800 tracking-tight leading-tight mb-2">
                            Granular Room Setup 🏫
                        </h2>
                        <p className="text-gray-500 mb-6 font-medium">Set detailed information for each room in your registered buildings.</p>

                        <div className="space-y-6">
                            {roomsData.length === 0 && (
                                <div className="bg-amber-50 p-8 rounded-3xl border-2 border-amber-200 text-center">
                                    <p className="text-amber-800 font-bold">No rooms generated yet. Please register a building first!</p>
                                    <button onClick={() => setCurrentPage(2)} className="mt-4 px-6 py-2 bg-amber-500 text-white rounded-xl font-bold">Go to Step 2</button>
                                </div>
                            )}

                            {roomsData.slice((roomsPage - 1) * roomsPerPage, roomsPage * roomsPerPage).map((room) => {
                                const building = allBuildings.find(b => b.id === room.building_local_id);
                                return (
                                    <div key={room.id} className="bg-white p-6 rounded-3xl shadow-sm border-2 border-gray-100">
                                        <div className="flex justify-between items-start mb-4">
                                            <div className="flex-1 mr-4">
                                                <input 
                                                    type="text" 
                                                    value={room.room_name} 
                                                    onChange={(e) => setRoomsData(roomsData.map(r => r.id === room.id ? { ...r, room_name: e.target.value } : r))}
                                                    className="font-black text-xl text-gray-800 bg-transparent border-b-2 border-dashed border-gray-200 focus:border-indigo-500 outline-none w-full"
                                                />
                                                <p className="text-xs font-bold text-gray-400 uppercase tracking-wider mt-1">{building?.building_name || 'N/A'}</p>
                                            </div>
                                            <span className={`text-[10px] font-black px-2 py-1 rounded-lg uppercase tracking-wider ${room.condition === 'Repair' ? 'bg-amber-100 text-amber-700' : 'bg-gray-100 text-gray-600'}`}>
                                                {room.condition}
                                            </span>
                                        </div>

                                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                                            <div>
                                                <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest block mb-1">Dimensions</label>
                                                <select 
                                                    value={room.dimensions} 
                                                    onChange={(e) => setRoomsData(roomsData.map(r => r.id === room.id ? { ...r, dimensions: e.target.value } : r))}
                                                    className="w-full bg-gray-50 border-2 border-gray-100 rounded-xl px-4 py-2 font-bold text-gray-700 outline-none focus:border-indigo-500"
                                                >
                                                    <option value="Less than 7x9">Less than 7x9</option>
                                                    <option value="7x9">7x9</option>
                                                    <option value="Above 7x9">Above 7x9</option>
                                                </select>
                                            </div>

                                            <div>
                                                <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest block mb-1">Condition</label>
                                                <select 
                                                    value={room.condition} 
                                                    onChange={(e) => setRoomsData(roomsData.map(r => r.id === room.id ? { ...r, condition: e.target.value } : r))}
                                                    className="w-full bg-gray-50 border-2 border-gray-100 rounded-xl px-4 py-2 font-bold text-gray-700 outline-none focus:border-indigo-500"
                                                >
                                                    <option value="Newly Built">Newly Built</option>
                                                    <option value="Good Condition">Good Condition</option>
                                                    <option value="Repair">Repair</option>
                                                </select>
                                            </div>

                                            <div>
                                                <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest block mb-1">Grade Level</label>
                                                <select 
                                                    value={room.grade_level} 
                                                    onChange={(e) => setRoomsData(roomsData.map(r => r.id === room.id ? { ...r, grade_level: e.target.value } : r))}
                                                    className="w-full bg-gray-50 border-2 border-gray-100 rounded-xl px-4 py-2 font-bold text-gray-700 outline-none focus:border-indigo-500"
                                                >
                                                    <option value="">Select Grade Level</option>
                                                    <option value="Kinder">Kinder</option>
                                                    {[1,2,3,4,5,6,7,8,9,10,11,12].map(g => <option key={g} value={`Grade ${g}`}>Grade {g}</option>)}
                                                    <option value="Non-Instructional">Non-Instructional</option>
                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                );
                            })}
                            
                            {/* Pagination Controls */}
                            {roomsData.length > roomsPerPage && (
                                <div className="flex justify-between items-center bg-gray-50 p-4 rounded-2xl">
                                    <button 
                                        onClick={() => setRoomsPage(prev => Math.max(prev - 1, 1))}
                                        disabled={roomsPage === 1}
                                        className="flex items-center gap-2 px-4 py-2 bg-white border-2 border-gray-200 rounded-xl font-bold text-gray-600 disabled:opacity-50"
                                    >
                                        <FiArrowLeft /> Previous
                                    </button>
                                    <span className="font-black text-gray-400 uppercase text-xs tracking-widest">
                                        Page {roomsPage} of {Math.ceil(roomsData.length / roomsPerPage)}
                                    </span>
                                    <button 
                                        onClick={() => setRoomsPage(prev => Math.min(prev + 1, Math.ceil(roomsData.length / roomsPerPage)))}
                                        disabled={roomsPage === Math.ceil(roomsData.length / roomsPerPage)}
                                        className="flex items-center gap-2 px-4 py-2 bg-white border-2 border-gray-200 rounded-xl font-bold text-indigo-600 disabled:opacity-50"
                                    >
                                        Next <FiArrowRight />
                                    </button>
                                </div>
                            )}
                        </div>
                    </motion.div>
                )}

                {/* ────────────────────────────────────────────────────────
                    PHASE 2: Repair Assessment
                    ──────────────────────────────────────────────────────── */}
                {currentPage === 4 && (
                    <motion.div initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }}>
                        <h2 className="text-3xl font-black text-gray-800 tracking-tight leading-tight mb-2">
                            Repair Assessment 🛠️
                        </h2>
                        <p className="text-gray-500 mb-6 font-medium">Assess rooms marked for repair during registration.</p>

                        <div className="space-y-6">
                            {roomsData.filter(r => r.condition === 'Repair').length === 0 ? (
                                <div className="bg-emerald-50 p-8 rounded-3xl border-2 border-emerald-100 text-center">
                                    <p className="text-emerald-800 font-bold text-xl">✨ All rooms are in good shape!</p>
                                    <p className="text-emerald-600 mt-2 font-medium">No rooms were marked for repair. You can proceed to the next step.</p>
                                </div>
                            ) : (
                                <div className="space-y-4">
                                    {roomsData.filter(r => r.condition === 'Repair').map(room => {
                                        const building = allBuildings.find(b => b.id === room.building_local_id);
                                        const isAssessed = repairAssessments.some(a => a.building_name === building?.building_name && a.room_name === room.room_name);
                                        
                                        return (
                                            <div key={room.id} className="bg-white p-6 rounded-3xl shadow-sm border-2 border-gray-100">
                                                <div className="flex justify-between items-center">
                                                    <div>
                                                        <h4 className="font-black text-xl text-gray-800">{room.room_name}</h4>
                                                        <p className="text-xs font-bold text-gray-400 mt-1 uppercase tracking-widest">{building?.building_name || 'N/A'}</p>
                                                        {isAssessed && <p className="text-xs font-black text-emerald-500 mt-2 uppercase flex items-center gap-1"><FiCheckCircle /> Assessment Recorded</p>}
                                                    </div>
                                                    <button 
                                                        onClick={() => {
                                                            setRepairRoomFormData({
                                                                building_name: building?.building_name || "",
                                                                room_name: room.room_name,
                                                                room_length: room.room_length || 9,
                                                                room_width: room.room_width || 7
                                                            });

                                                            // Populate previous assessments
                                                            const existingItems = repairAssessments.filter(a => 
                                                                a.building_name === building?.building_name && 
                                                                a.room_name === room.room_name
                                                            );
                                                            
                                                            const initialState = {};
                                                            existingItems.forEach(item => {
                                                                initialState[item.item] = {
                                                                    oms: item.oms || "",
                                                                    condition: item.condition || "Repair",
                                                                    damage_ratio: item.damage_ratio || 0,
                                                                    recommend_action: item.recommend_action || "Routine Repair",
                                                                    demo_justification: item.demo_justification || "",
                                                                    remarks: item.remarks || ""
                                                                };
                                                            });
                                                            setRepairItemsState(initialState);

                                                            setEditingRepairRoomId(building?.building_name + "-" + room.room_name);
                                                            setShowRepairModal(true);
                                                        }}
                                                        className={`p-4 rounded-2xl shadow-lg transition-all active:scale-95 ${isAssessed ? 'bg-indigo-50 text-indigo-500 shadow-indigo-100' : 'bg-amber-500 text-white shadow-amber-100'}`}
                                                    >
                                                        {isAssessed ? <FiEdit2 className="w-6 h-6" /> : <FiPlus className="w-6 h-6" />}
                                                    </button>
                                                </div>
                                            </div>
                                        );
                                    })}
                                </div>
                            )}

                            {showRepairModal && (
                                <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="bg-white p-6 rounded-[2rem] shadow-xl border-2 border-amber-100 mt-10">
                                    <div className="flex justify-between items-center mb-6 border-b-2 border-gray-50 pb-4">
                                        <h3 className="font-black text-2xl text-gray-800">Assessment: {repairRoomFormData.room_name}</h3>
                                        <button onClick={() => setShowRepairModal(false)} className="text-gray-400 hover:text-gray-700 bg-gray-50 p-2 rounded-full"><FiX className="w-6 h-6" /></button>
                                    </div>

                                    {/* Item Checklist */}
                                    <h4 className="font-bold text-gray-700 mb-4 px-1">Checklist of Damaged Items</h4>
                                    <div className="space-y-4 mb-8">
                                        {REPAIR_CATEGORIES.map(category => {
                                            const isChecked = !!repairItemsState[category];
                                            const itemData = repairItemsState[category] || {};

                                            return (
                                                <div key={category} className={`border-2 rounded-2xl overflow-hidden transition-all ${isChecked ? 'border-amber-400 bg-amber-50/30' : 'border-gray-100 bg-white'}`}>
                                                    <label className="flex items-center gap-3 p-4 cursor-pointer hover:bg-gray-50">
                                                        <input type="checkbox" checked={isChecked} onChange={() => handleToggleRepairItem(category)}
                                                            className="w-6 h-6 rounded text-amber-500 focus:ring-amber-500 border-gray-300" />
                                                        <span className={`font-bold text-lg ${isChecked ? 'text-amber-800' : 'text-gray-600'}`}>{category}</span>
                                                    </label>

                                                    {isChecked && (
                                                        <div className="p-4 pt-0 space-y-4 border-t border-amber-100 mt-2">
                                                            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                                                                <div>
                                                                    <label className="text-xs font-bold text-gray-500">What it is made of</label>
                                                                    <input type="text" value={itemData.oms} onChange={(e) => handleUpdateRepairItem(category, 'oms', e.target.value)}
                                                                        className="w-full bg-white border-2 border-gray-200 mt-1 rounded-xl px-3 py-2 text-sm font-bold text-gray-700 outline-none focus:border-amber-500" placeholder="e.g. GI Sheet, Concrete, Wood" />
                                                                </div>
                                                                <div>
                                                                    <label className="text-xs font-bold text-gray-500">Action</label>
                                                                    <select value={itemData.recommend_action} onChange={(e) => handleUpdateRepairItem(category, 'recommend_action', e.target.value)}
                                                                        className="w-full bg-white border-2 border-gray-200 mt-1 rounded-xl px-3 py-2 text-sm font-bold text-gray-700 outline-none focus:border-amber-500 appearance-none">
                                                                        <option value="Routine Repair">Routine Repair</option>
                                                                        <option value="Major Repair / Rehabilitation">Major Repair / Rehabilitation</option>
                                                                        <option value="Structural Retrofit">Structural Retrofit</option>
                                                                        <option value="Recommend for Condemnation">Recommend for Condemnation</option>
                                                                        <option value="Recommend for Demolition">Recommend for Demolition</option>
                                                                    </select>
                                                                </div>
                                                            </div>

                                                            {itemData.recommend_action === 'Recommend for Demolition' && (
                                                                <div className="bg-rose-50 p-3 rounded-xl border border-rose-100">
                                                                    <label className="text-[10px] font-black uppercase tracking-wider text-rose-500 mb-1 block">Demolition Justification</label>
                                                                    <select value={itemData.demo_justification} onChange={(e) => handleUpdateRepairItem(category, 'demo_justification', e.target.value)}
                                                                        className="w-full bg-white border-2 border-rose-200 rounded-lg px-3 py-2 text-sm font-bold text-rose-700 outline-none focus:border-rose-500">
                                                                        <option value="">-- Select Justification --</option>
                                                                        <option value="Beyond repair due to age and lifecycle">Beyond repair due to age and lifecycle</option>
                                                                        <option value="Structural or safety issues">Structural or safety issues</option>
                                                                        <option value="Severe damage due to calamity">Severe damage due to calamity</option>
                                                                        <option value="MGB‑declared hazard‑prone area">MGB‑declared hazard‑prone area</option>
                                                                        <option value="Site relocation or right-of-way">Site relocation or right-of-way</option>
                                                                    </select>
                                                                </div>
                                                            )}

                                                            <div className="flex gap-4">
                                                                <div className="flex-1">
                                                                    <label className="text-xs font-bold text-gray-500">Damage Ratio</label>
                                                                    <input type="range" min="0" max="100" value={itemData.damage_ratio} onChange={(e) => handleUpdateRepairItem(category, 'damage_ratio', parseInt(e.target.value))}
                                                                        className="w-full mt-2 accent-amber-500 h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer" />
                                                                    <div className="text-right text-xs font-black text-amber-600 mt-1">{itemData.damage_ratio}%</div>
                                                                </div>
                                                            </div>

                                                            <div>
                                                                <label className="text-[10px] font-bold text-gray-400 ml-1">REMARKS</label>
                                                                <input type="text" value={itemData.remarks} onChange={(e) => handleUpdateRepairItem(category, 'remarks', e.target.value)}
                                                                    className="w-full bg-white border-2 border-gray-100 mt-0.5 rounded-lg px-3 py-1.5 text-xs font-medium text-gray-600 outline-none focus:border-amber-400" placeholder="Additional notes..." />
                                                            </div>
                                                        </div>
                                                        )}
                                                    </div>
                                                );
                                            })}
                                        </div>

                                        <button onClick={handleSaveRepairRoom}
                                            className="w-full mt-6 py-4 rounded-2xl text-white font-black text-lg bg-amber-500 border-b-[6px] border-amber-700 active:border-b-0 active:translate-y-[6px] transition-all shadow-xl shadow-amber-200/50">
                                            Save Room Assessment ✓
                                    </button>
                                </motion.div>
                            )}
                            </div>

                        {/* FINAL SUBMIT BUTTON on Page 4 */}
                        <div className="mt-12 p-8 bg-indigo-600 rounded-[2.5rem] shadow-2xl shadow-indigo-200 relative overflow-hidden">
                            <div className="absolute top-0 right-0 p-6 opacity-10">
                                <FiCheckCircle className="w-32 h-32 text-white" />
                            </div>
                            <h3 className="text-white font-black text-3xl mb-2 relative z-10">Finalize Audit ✨</h3>
                            <p className="text-indigo-100 font-medium mb-8 relative z-10">Ready to save all your Physical Facilities data for this school?</p>

                            <button onClick={handleMasterSubmit} disabled={loading}
                                className="w-full py-5 rounded-2xl bg-white text-indigo-600 font-black text-2xl shadow-xl hover:scale-[1.02] active:scale-[0.98] transition-all flex items-center justify-center gap-3 disabled:opacity-50 border-b-[6px] border-indigo-200 active:border-b-0 active:translate-y-[6px]">
                                {loading ? "Processing..." : "Submit Unit Audit"}
                                <FiArrowRight className="w-6 h-6" />
                            </button>
                        </div>
                    </motion.div>
                )}

                </main>

                {/* Wizard Navigation Buttons */}
                <footer className="fixed bottom-0 left-0 w-full p-6 pb-10 bg-white/80 backdrop-blur-md border-t border-slate-100 flex justify-center z-30 pointer-events-none">
                    <div className="w-full max-w-sm flex gap-3 pointer-events-auto">
                        <button onClick={() => setShowDraftModal(true)} className="w-16 h-16 rounded-3xl bg-gray-100 flex items-center justify-center text-gray-400 hover:text-gray-900 active:scale-95 transition-all outline-none shrink-0">
                             <FiSave className="w-6 h-6" />
                        </button>
                        
                        {currentPage === 4 ? (
                            <button onClick={handleMasterSubmit} disabled={loading}
                                className="flex-1 py-5 rounded-3xl bg-indigo-600 text-white font-black text-xl shadow-xl hover:scale-[1.02] active:scale-[0.98] transition-all flex items-center justify-center gap-3 disabled:opacity-50 border-b-[6px] border-indigo-200 active:border-b-0 active:translate-y-[6px]">
                                {loading ? "Processing..." : "Submit Unit Audit"}
                                <FiArrowRight className="w-6 h-6" />
                            </button>
                        ) : (
                            <button
                                onClick={() => {
                                    // Validation for Phase 2 Step 3: Granular Room Setup
                                    if (currentPage === 3) {
                                        const missingGradeLevel = roomsData.some(r => !r.grade_level);
                                        if (missingGradeLevel) {
                                            alert("Please select a Granular Grade Level for all classrooms before proceeding.");
                                            return;
                                        }
                                    }
                                    setCurrentPage(prev => prev + 1);
                                    handlePartialSync();
                                }}
                                className="flex-1 py-5 rounded-3xl bg-indigo-500 text-white font-black text-xl flex items-center justify-center gap-2 shadow-lg shadow-indigo-100 hover:bg-indigo-600 transition-all border-b-[6px] border-indigo-700 active:border-b-0 active:translate-y-[6px]"
                            >
                                Next Step <FiArrowRight className="w-6 h-6" />
                            </button>
                        )}
                    </div>
                </footer>

            <SuccessModal
                isOpen={showSuccess}
                onClose={() => {
                    setShowSuccess(false);
                    navigate("/modular-dashboard");
                }}
                message="Unit 8 Physical Facilities Audit finalized and saved successfully! ✨"
                redirectUrl="/modular-dashboard"
            />

            <AnimatePresence>
                {showDraftModal && (
                    <div className="fixed inset-0 bg-gray-900/60 backdrop-blur-md z-[100] flex items-end justify-center pointer-events-auto">
                        <motion.div initial={{ y: 300 }} animate={{ y: 0 }} exit={{ y: 300 }} transition={{ type: "spring", damping: 25, stiffness: 200 }}
                            className="bg-white w-full max-w-md rounded-t-[3rem] p-10 pb-12 shadow-2xl relative text-left">
                            <div className="w-16 h-1.5 bg-gray-200 rounded-full mx-auto mb-8" />
                            <div className="w-20 h-20 bg-blue-500 rounded-full mx-auto flex items-center justify-center text-3xl shadow-2xl shadow-blue-200 mb-6 font-bold text-white">
                                <FiSave />
                            </div>
                            <h2 className="text-2xl font-black text-gray-900 text-center leading-tight">Save Progress?</h2>
                            <p className="text-gray-500 text-center font-medium mt-3 px-4">Would you like to save your progress and go back to the modules overview?</p>
                            
                            <div className="grid grid-cols-2 gap-4 mt-10">
                                <button onClick={() => setShowDraftModal(false)}
                                    className="py-5 rounded-[2rem] bg-gray-100 text-gray-900 font-black text-lg active:scale-95 transition-all outline-none">
                                    Continue
                                </button>
                                <button onClick={handleSaveDraftAndExit}
                                    className="py-5 rounded-[2rem] bg-blue-600 text-white font-black text-lg shadow-xl shadow-blue-100 active:scale-95 transition-all outline-none">
                                    Save & Exit
                                </button>
                            </div>
                        </motion.div>
                    </div>
                )}
            </AnimatePresence>
        </div>
    );
}
