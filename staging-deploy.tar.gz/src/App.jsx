import { HashRouter as Router, Routes, Route, useLocation, Navigate, useNavigate } from 'react-router-dom';

// ... (lines 3-118 remain same, but I can't express that in one chunk easily if imports are at top and usage at bottom. I'll use 2 chunks)

import { AnimatePresence } from 'framer-motion'; // <--- IMPORT THIS
import MaintenanceScreen from './components/MaintenanceScreen'; // <--- IMPORT MAINTENANCE SCREEN
import SuperUserFloatingSwitch from './components/SuperUserFloatingSwitch'; // Super User Switch
import ChatWidget from './components/ChatWidget'; // Chatbot Widget
import { useState, useEffect } from 'react'; // Ensure React hooks are imported

// Auth
import Login from './Login';
import Register from './Register';
import { AuthProvider, useAuth } from './context/AuthContext';

// Dashboards
import EngineerDashboard from './modules/EngineerDashboard';
import EngineerProjects from './modules/EngineerProjects';

// import LguDashboard from './modules/lgu'; // Import LguDashboard
// import LguProjects from './modules/LguProjects';
import SchoolHeadDashboard from './modules/SchoolHeadDashboard';
import HRDashboard from './modules/HRDashboard';
import AdminDashboard from './modules/AdminDashboard';
import MonitoringDashboard from './modules/MonitoringDashboard';
import SchoolManagement from './modules/SchoolManagement';
import DummyDashboard from './modules/DummyDashboard';
import SchoolJurisdictionList from './modules/SchoolJurisdictionList';
import SchoolAuditView from './modules/SchoolAuditView';
import UserProfile from './modules/UserProfile';
import Activity from './modules/Activity';
import MyActivityDashboard from './modules/MyActivityDashboard';
import ProjectGallery from './modules/ProjectGallery';
import Outbox from './modules/Outbox';
import EngineerOutbox from './modules/EngineerOutbox';
import SuperAdminDashboard from './modules/SuperAdminDashboard';
import SuperUserSelector from './modules/SuperUserSelector';
import FinanceDashboard from './modules/FinanceDashboard';
import AgencyDashboard from './modules/AgencyDashboard';
import LguDashboard from './modules/LguDashboard';
import NonDepEdDashboard from './modules/NonDepEdDashboard'; // Dedicated Dashboard
import LguForms from './modules/LguForms'; // Import newly created LguForms
import LguProjectDetails from './modules/LguProjectDetails'; // Import LguProjectDetails
import PSIP from './modules/PSIP'; // Import PSIP
import ProtectedRoute from './components/ProtectedRoute'; // Import ProtectedRoute
import PasscodeSetupPrompt from './components/PasscodeSetupPrompt'; // <--- IMPORT THIS
import EFDHome from './modules/EFDHome';
import EFDMonitoring from './modules/EFDMonitoring';
import EFDNewconMonitoring from './modules/EFDNewconMonitoring';
import EFDMotherMoa from './modules/EFDMotherMoa';
import BEFFDashboard from './modules/BEFFDashboard';
import ChatModule from './modules/ChatModule';



// Forms
import SchoolForms from './modules/SchoolForms';
import EngineerForms from './modules/EngineerForms';

// Form Imports (School Head)
import SchoolProfile from './forms/SchoolProfile';
import SchoolInformation from './forms/SchoolInformation';
import Enrolement from './forms/Enrolment';
import OrganizedClasses from './forms/OrganizedClasses';
import TeachingPersonnel from './forms/TeachingPersonnel';
import ShiftingModalities from './forms/ShiftingModalities';
import SchoolResources from './forms/SchoolResources';
import TeacherSpecialization from './forms/TeacherSpecialization';
import PhysicalFacilities from './forms/PhysicalFacilities';
import LearnerStatistics from './forms/LearnerStatistics';

// Form Imports (DepEd Engineer)
import EngineerSchoolResources from './forms/EngineerSchoolResources';
import DamageAssessment from './forms/DamageAssessment';
import ProjectMonitoring from './forms/ProjectMonitoring';
import SiteInspection from './forms/SiteInspection';
import MaterialInventory from './forms/MaterialInventory';
import NewProjects from './modules/NewProjects';
import DetailedProjInfo from './modules/DetailedProjInfo';
import ProjectValidation from './modules/ProjectValidation';
import Leaderboard from './modules/Leaderboard';

// School Head Modular Flow
import ModularDashboard from './components/ModularDashboard';
import Unit1SchoolIdentity from './components/modular/Unit1SchoolIdentity';
import Unit2Learners from './components/modular/Unit2Learners';
import Unit3OrganizedClasses from './components/modular/Unit3OrganizedClasses';
import Unit4LearnerProfile from './components/modular/Unit4LearnerProfile';
import Unit5ShiftingModality from './components/modular/Unit5ShiftingModality';
import TeachingPersonnelUnit from './components/modular/TeachingPersonnel';
import Unit7SchoolResources from './components/modular/Unit7SchoolResources';
import Unit8PhysicalFacilities from './components/modular/Unit8PhysicalFacilities';
import Unit9SchoolLocation from './components/modular/Unit9SchoolLocation';

// Nexus & Drafts
import NexusDashboard from './modules/NexusDashboard';
import ESF7Draft from './forms/ESF7Draft';
import NSPPDraft from './forms/NSPPDraft';
import ESF7Review from './modules/ESF7Review';


// --- WRAPPER COMPONENT TO HANDLE LOCATION ---
const AnimatedRoutes = () => {
  const { user, loading } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();

  useEffect(() => {
    // List of public paths that don't require authentication
    const publicPaths = ['/', '/register', '/adminlogin'];
    
    // If auth is finished loading and no user is found on a non-public path, redirect to login
    if (!loading && !user && !publicPaths.includes(location.pathname)) {
      console.log("[App] No user session found on protected route. Redirecting to login...");
      navigate('/', { replace: true });
    }
  }, [user, loading, location.pathname, navigate]);

  const [maintenanceMode, setMaintenanceMode] = useState(false);
  const [checkingMaintenance, setCheckingMaintenance] = useState(true);

  // Check Maintenance Status on Route Change
  useEffect(() => {
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 4000); // 4s timeout

    const checkMaintenance = async () => {
      try {
        const res = await fetch('/api/settings/maintenance_mode', { signal: controller.signal });
        const text = await res.text();
        const data = text ? JSON.parse(text) : {};
        setMaintenanceMode(data.value === 'true');
      } catch (err) {
        if (err.name === 'AbortError') {
          console.warn("Maintenance check timed out, proceeding anyway.");
        } else {
          console.error("Maintenance Check Failed:", err);
        }
      } finally {
        clearTimeout(timeoutId);
        setCheckingMaintenance(false);
      }
    };
    checkMaintenance();
    
    return () => {
      clearTimeout(timeoutId);
      controller.abort();
    };
  }, [location.pathname]); // Re-check on nav

  if (checkingMaintenance) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-slate-50">
        <div className="flex flex-col items-center gap-4">
          <div className="w-12 h-12 border-4 border-blue-600 border-t-transparent rounded-full animate-spin"></div>
          <p className="text-slate-500 font-medium animate-pulse">Initializing InsightEd...</p>
        </div>
      </div>
    );
  }

  const role = localStorage.getItem('userRole');
  const isProtected = location.pathname !== '/' && location.pathname !== '/register';
  const isAdmin = role === 'Admin' || role === 'Super Admin' || role === 'Super User';

  // if (maintenanceMode && isProtected && !isAdmin) {
  //   return <MaintenanceScreen />;
  // }

  return (
    <Routes>
      {/* Authentication */}
      <Route path="/" element={<Login />} />
      <Route path="/register" element={<Register />} />

        {/* Dashboards */}
        <Route path="/engineer-dashboard" element={<EngineerDashboard />} />
        <Route path="/non-deped-dashboard" element={<NonDepEdDashboard />} />
        {/* <Route path="/lgu" element={<LguDashboard />} /> */}
        {/* <Route path="/lgu-form" element={<LguForm />} /> */}
        {/* <Route path="/lgu-projects" element={<LguProjects />} /> */}
        <Route path="/engineer-projects" element={<EngineerProjects />} />
        <Route path="/super-admin" element={<Navigate to="/super-user-selector" replace />} />
        <Route path="/finance-dashboard" element={<FinanceDashboard />} />
        <Route path="/lgu-dashboard" element={<LguDashboard />} />
        <Route path="/lgu-form" element={<LguForms />} /> {/* Mapped to LguForms */}
        <Route path="/lgu-project-details/:id" element={<LguProjectDetails />} />

      {/* Super User Selector (Protected) */}
      <Route
        path="/super-user-selector"
        element={
          <ProtectedRoute allowedRoles={['Super User']}>
            <SuperUserSelector />
          </ProtectedRoute>
        }
      />

      <Route path="/schoolhead-dashboard" element={<SchoolHeadDashboard />} />
      <Route path="/hr-dashboard" element={<HRDashboard />} />
      <Route path="/admin-dashboard" element={<AdminDashboard />} />
      <Route path="/monitoring-dashboard" element={<MonitoringDashboard />} />
      <Route path="/efd-dashboard" element={<EFDHome />} />
      <Route path="/agency-dashboard" element={<AgencyDashboard />} />
      <Route path="/efd-monitoring" element={<EFDMonitoring />} />
      <Route path="/beff-dashboard" element={<BEFFDashboard />} />
      <Route path="/efd-newcon-monitoring" element={<EFDNewconMonitoring />} />
      <Route path="/efd-mother-moa" element={<EFDMotherMoa />} />
      <Route path="/school-management" element={<SchoolManagement />} />
      <Route path="/jurisdiction-schools" element={<SchoolJurisdictionList />} />
      <Route path="/school-audit" element={<SchoolAuditView />} />
      <Route path="/esf7-review" element={<Navigate to="/esf7/review" replace />} />
      <Route path="/esf7/review" element={<ProtectedRoute allowedRoles={['Division Engineer', 'Admin', 'Super User', 'Regional Office', 'School Division Office']}><ESF7Review /></ProtectedRoute>} />
      <Route path="/dummy-forms" element={<DummyDashboard />} />

      <Route path="/dummy-forms" element={<DummyDashboard />} />
      <Route path="/psip" element={<PSIP />} />

        {/* School Head Modular Flow */}
        <Route
          path="/modular-dashboard"
          element={
            <ProtectedRoute allowedRoles={['School Head']}>
              <ModularDashboard />
            </ProtectedRoute>
          }
        />
        <Route
          path="/my-activity"
          element={
            <ProtectedRoute allowedRoles={['School Head']}>
              <MyActivityDashboard />
            </ProtectedRoute>
          }
        />
        <Route
          path="/activity-dashboard"
          element={
            <ProtectedRoute allowedRoles={['School Head']}>
              <MyActivityDashboard />
            </ProtectedRoute>
          }
        />
        <Route
          path="/nexus-dashboard"
          element={
            <ProtectedRoute allowedRoles={['School Head']}>
              <NexusDashboard />
            </ProtectedRoute>
          }
        />
        <Route
          path="/draft/esf7"
          element={
            <ProtectedRoute allowedRoles={['School Head']}>
              <ESF7Draft />
            </ProtectedRoute>
          }
        />
        <Route
          path="/draft/nspp"
          element={
            <ProtectedRoute allowedRoles={['School Head']}>
              <NSPPDraft />
            </ProtectedRoute>
          }
        />
        <Route
          path="/modular/unit-1"
          element={
            <ProtectedRoute allowedRoles={['School Head']}>
              <Unit1SchoolIdentity />
            </ProtectedRoute>
          }
        />
        <Route
          path="/modular/unit-2"
          element={
            <ProtectedRoute allowedRoles={['School Head']}>
              <Unit2Learners />
            </ProtectedRoute>
          }
        />
        <Route
          path="/modular/unit-3"
          element={
            <ProtectedRoute allowedRoles={['School Head']}>
              <Unit3OrganizedClasses />
            </ProtectedRoute>
          }
        />
        <Route
          path="/modular/unit-4"
          element={
            <ProtectedRoute allowedRoles={['School Head']}>
              <Unit4LearnerProfile />
            </ProtectedRoute>
          }
        />
        <Route
          path="/modular/unit-5"
          element={
            <ProtectedRoute allowedRoles={['School Head']}>
              <Unit5ShiftingModality />
            </ProtectedRoute>
          }
        />
        <Route
          path="/modular/unit-6"
          element={
            <ProtectedRoute allowedRoles={['School Head']}>
              <TeachingPersonnelUnit />
            </ProtectedRoute>
          }
        />
        <Route
          path="/modular/unit-7"
          element={
            <ProtectedRoute allowedRoles={['School Head']}>
              <Unit7SchoolResources />
            </ProtectedRoute>
          }
        />
        <Route
          path="/modular/unit-8"
          element={
            <ProtectedRoute allowedRoles={['School Head']}>
              <Unit8PhysicalFacilities />
            </ProtectedRoute>
          }
        />
        <Route
          path="/modular/unit-9"
          element={
            <ProtectedRoute allowedRoles={['School Head']}>
              <Unit9SchoolLocation />
            </ProtectedRoute>
          }
        />
        <Route path="/chat" element={<ChatModule />} />

      {/* Menus */}
      <Route path="/school-forms" element={<SchoolForms />} />
      <Route path="/engineer-forms" element={<EngineerForms />} />

      {/* Utilities */}
      <Route path="/profile" element={<UserProfile />} />
      <Route path="/activities" element={<Activity />} />
      <Route path="/outbox" element={<Outbox />} />
      <Route path="/engineer-outbox" element={<EngineerOutbox />} />

      {/* School Head Forms */}
      <Route path="/school-profile" element={<SchoolProfile />} />
      <Route path="/school-information" element={<SchoolInformation />} />
      <Route path="/enrolment" element={<Enrolement />} />
      <Route path="/organized-classes" element={<OrganizedClasses />} />
      <Route path="/teaching-personnel" element={<TeachingPersonnel />} />
      <Route path="/school-resources" element={<SchoolResources />} />
      <Route path="/physical-facilities" element={<PhysicalFacilities />} />
      <Route path="/teacher-specialization" element={<TeacherSpecialization />} />
      <Route path="/shifting-modalities" element={<ShiftingModalities />} />
      <Route path="/learner-statistics" element={<LearnerStatistics />} />
      <Route path="/project-validation" element={<ProjectValidation />} />
      <Route path="/leaderboard" element={<Leaderboard />} />

      {/* DepEd Engineer Forms */}
      <Route path="/engineer-school-resources" element={<EngineerSchoolResources />} />
      <Route path="/damage-assessment" element={<DamageAssessment />} />
      <Route path="/project-monitoring" element={<ProjectMonitoring />} />
      <Route path="/site-inspection" element={<SiteInspection />} />
      <Route path="/material-inventory" element={<MaterialInventory />} />
      <Route path="/new-project" element={<NewProjects />} />
      <Route path="/project-details/:id" element={<DetailedProjInfo />} />
      <Route path="/project-gallery" element={<ProjectGallery />} />
      <Route path="/project-gallery/:projectId" element={<ProjectGallery />} />
      <Route path="/project-gallery/:projectId" element={<ProjectGallery />} />

      {/* Hidden Admin Login Route */}
      <Route path="/adminlogin" element={<Login />} />
    </Routes>
  );
};

import GlobalErrorBoundary from './components/GlobalErrorBoundary';
import ScrollToTop from './components/ScrollToTop';

function App() {
  return (
    <GlobalErrorBoundary>
      <Router>
        <AppContent />
      </Router>
    </GlobalErrorBoundary>
  );
}

const AppContent = () => {
  const location = useLocation();
  const showChatFloating = (location.pathname === '/' || location.pathname === '/adminlogin') && location.pathname !== '/chat';

  return (
    <>
      <ScrollToTop />
      <SuperUserFloatingSwitch />
      <ChatWidget showFloatingButton={showChatFloating} />
      <PasscodeSetupPrompt />
      <AnimatedRoutes />
    </>
  );
};

export default App;