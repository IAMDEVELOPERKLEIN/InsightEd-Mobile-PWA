import React from 'react'
import { StrictMode } from 'react'
import { createRoot } from 'react-dom/client'

// GUARANTEE: Expose React globally for any third-party dependencies 
// that rely on it instead of ES module imports.
window.React = window.React || React;

import './index.css'
import App from './App.jsx'
import { ThemeProvider } from './context/ThemeContext'
import { ServiceWorkerProvider } from './context/ServiceWorkerContext'
import { AuthProvider } from './context/AuthContext'

createRoot(document.getElementById('root')).render(
  <StrictMode>
    <AuthProvider>
      <ThemeProvider>
        <ServiceWorkerProvider>
          <App />
        </ServiceWorkerProvider>
      </ThemeProvider>
    </AuthProvider>
  </StrictMode>,
)